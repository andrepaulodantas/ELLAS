import React from 'react';

const ApoieEllas: React.FC = () => {
  return (
    <div>
      <h1>Apoie ELLAS</h1>
      <p>Esta é a página Apoie ELLAS.</p>
    </div>
  );
};

export default ApoieEllas;

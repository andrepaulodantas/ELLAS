const Services = require("./Services.js");

class PessoaServices extends Services {
    constructor() {
        super('Pessoa');
    }
}

module.exports = PessoaServices;
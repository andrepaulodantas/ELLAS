import React from 'react';

const Contato: React.FC = () => {
  return (
    <div>
      <h1>Contato</h1>
      <p>Esta é a página Contato.</p>
    </div>
  );
};

export default Contato;

const { usuarios } = require('../models');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

class AuthController {
  async login(req, res) {
    const { email, password } = req.body;
    try {
      const user = await usuarios.findOne({ where: { email } });
      if (!user) {
        return res.status(404).json({ message: 'Usuário não encontrado' });
      }

      const isPasswordValid = await bcrypt.compare(password, user.senha);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Senha inválida' });
      }

      const token = jwt.sign({ id: user.id }, 'seu-segredo-jwt', { expiresIn: '1h' });
      return res.status(200).json({ token });
    } catch (error) {
      return res.status(500).json(error.message);
    }
  }
}

module.exports = AuthController;

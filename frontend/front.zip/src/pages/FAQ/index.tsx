import React from 'react';

const Faq: React.FC = () => {
  return (
    <div>
      <h1>FAQ</h1>
      <p>Esta é a página FAQ.</p>
    </div>
  );
};

export default Faq;

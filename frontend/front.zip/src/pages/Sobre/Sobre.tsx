import React from 'react';

const Sobre: React.FC = () => {
  return (
    <div>
      <h1>Sobre</h1>
      <p>Esta é a página Sobre.</p>
    </div>
  );
};

export default Sobre;

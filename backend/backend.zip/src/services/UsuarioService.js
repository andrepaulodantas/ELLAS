const Services = require('./Services');

class UsuarioService extends Services {
  constructor() {
    super('Usuario');
  }
}

module.exports = UsuarioService;
